This directory includes etcd project internal documentation for new and existing contributors.

For user and developer documentation please go to [etcd.io](https://etcd.io/),
which is developed in [website](https://github.com/etcd-io/website/) repo.
